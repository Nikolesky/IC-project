#include <gtk/gtk.h>
#include <gtk/gtkwidget.h>
#include "B24EE1087_B24MT1045_B24MT1004_B24CI1031_snake.h"

#define NODE_SIZE 10

// Declare the global drawing area
GtkWidget *global_drawing_area = NULL;

gboolean update_game(gpointer data) {
    game_params *params = (game_params *)data;

    int width, height;
    GtkNative *native = gtk_widget_get_native(global_drawing_area);  // Or any widget inside the window
    if (native) {
        GdkSurface *surface = gtk_native_get_surface(native);
        if (surface) {
            width = gdk_surface_get_width(surface);
            height = gdk_surface_get_height(surface);
        }
    }

    // Here you can update the game state, e.g., move the snake
    add_head(params->SNAKE);

    if(eat_food(params->SNAKE,params->food)==0){
        remove_tail(params->SNAKE);
    }

    if (check_collision(params->SNAKE, height, width) == 1) {
    // Create a new window
    GtkWidget *game_over_window = gtk_window_new();
    gtk_window_set_title(GTK_WINDOW(game_over_window), "Game Over");
    gtk_window_set_default_size(GTK_WINDOW(game_over_window), 300, 300);

    // Create a label with "Game Over"
    GtkWidget *label = gtk_label_new("    UH-OH!\nGame Over!!");
    gtk_widget_set_halign(label, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(label, GTK_ALIGN_CENTER);
    gtk_widget_set_margin_top(label, 50);
    gtk_widget_add_css_class(label, "game-over-label");

    // Add label to window
    gtk_window_set_child(GTK_WINDOW(game_over_window), label);

    // Apply CSS for black background and white text
    GtkCssProvider *provider = gtk_css_provider_new();
    gtk_css_provider_load_from_data(provider,
        "* { background-color: black; color: white; font-size: 28px; }",
        -1);

    GtkStyleContext *context = gtk_widget_get_style_context(game_over_window);
    gtk_style_context_add_provider(context, GTK_STYLE_PROVIDER(provider), GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

    gtk_window_present(GTK_WINDOW(game_over_window));

    return FALSE;  // Stop the game loop
}else{
        params->food = update_position(params->food,params->SNAKE);
    }

    // Queue the drawing area to redraw
    if (global_drawing_area != NULL) {
        gtk_widget_queue_draw(global_drawing_area);
    }

    // Return TRUE to keep the timeout running
    return TRUE;
}

static void draw_cb(GtkDrawingArea *area, cairo_t *cr, int width, int height, gpointer user_data) {
    game_params* params = (game_params*)user_data;
    snake* SNAKE = params->SNAKE;

    // black background
    cairo_set_source_rgb(cr, 0.3 ,0.3, 0.6);
    cairo_paint(cr);

    // Draw walls with text box that says �SCORE: <(no of nodes-1)*100> after the first apple is eaten
    // Text box
    cairo_set_source_rgb(cr, 0, 0, 1);
    cairo_set_line_width(cr, 1);  // By default the stroke line is 2 units thick
    cairo_rectangle(cr, width - 130, 0, 120, 20);
    cairo_stroke(cr);  // Only outlines the rectangle

    // Text
    cairo_set_source_rgb(cr, 1, 1, 0);  // Black
    cairo_select_font_face(cr, "Sans", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);
    cairo_set_font_size(cr, 18);  // Set font size
    cairo_move_to(cr, width - 125, 15);  // Set position (x=100, y=100)

    char score_text[50];
    int score = (count_nodes(SNAKE) - 1) * 100;  // Subtract 1 because initial head isn't a score

    if (count_nodes(SNAKE) > 1) {
        sprintf(score_text, "SCORE: %d", score);
    } else {
        sprintf(score_text, "SCORE: 000");
    }

    cairo_show_text(cr, score_text);

    // Draw wall
    cairo_set_source_rgb(cr, 0.45, 0.45,0.75);  // Grey - Blue
    cairo_rectangle(cr, 0, 21, width, 10);
    cairo_rectangle(cr, 0, height - 10, width, 10);
    cairo_rectangle(cr, 0, 21, 10, height);
    cairo_rectangle(cr, width - 10, 21, 10, height);
    cairo_fill(cr);

    // Draw the snake
    node* current = SNAKE->head;
    while (current != NULL) {
            cairo_set_source_rgb(cr, 0, 1, 0);  // green
            cairo_rectangle(cr, current->x, current->y, NODE_SIZE, NODE_SIZE);
            cairo_fill_preserve(cr);                // Fill, but keep path for stroke

            // Set stroke color (black) and width
            cairo_set_source_rgb(cr, 0.0, 0.0, 0.0); // RGB for black
            cairo_set_line_width(cr, 2.0);           // Thickness of the outline
            cairo_stroke(cr);                        // Draw the outline
            current = current->next;
    }

    // Draw food
    cairo_set_source_rgb(cr, 1, 0, 0);  // red
    cairo_rectangle(cr, params->food.x, params->food.y, 10, 10);
    cairo_fill(cr);
}

static void activate(GtkApplication *app, gpointer user_data) {
    game_params *params = (game_params *)user_data;

    GtkWidget *window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "Snake Game");
    gtk_window_set_default_size(GTK_WINDOW(window), WINDOW_SIZE, WINDOW_SIZE);

    GtkWidget *drawing_area = gtk_drawing_area_new();
    global_drawing_area = drawing_area;

    gtk_drawing_area_set_draw_func(GTK_DRAWING_AREA(drawing_area), draw_cb, params, NULL);
    gtk_window_set_child(GTK_WINDOW(window), drawing_area);

    // Create key event controller
    GtkEventController *key_controller = gtk_event_controller_key_new();

    // Connect the key-pressed signal to the on_key_pressed function
    g_signal_connect(key_controller, "key-pressed", G_CALLBACK(on_key_pressed), params);

    // Add the key controller to the window
    gtk_widget_add_controller(window, key_controller);

    gtk_window_present(GTK_WINDOW(window));

    // Start timer to update game every 200 ms
    g_timeout_add(100, update_game, params);
}

int main(int argc, char **argv) {
    GtkApplication *app = gtk_application_new("com.solution.Snake", G_APPLICATION_DEFAULT_FLAGS);

    // Allocate memory for game_params and initialize snake
    game_params* params = (game_params*)malloc(sizeof(game_params));
    params->SNAKE = (snake*)malloc(sizeof(snake));
    initialize_snake(params->SNAKE);

    // Initialize food position, ensuring it doesn't spawn on the snake
    int clash;
    do {
        clash = 0;
        params->food.x = ((rand() % ((WINDOW_SIZE - 20) / 10)) * 10) + 10;
        params->food.y = ((rand() % ((WINDOW_SIZE - 40) / 10)) * 10) + 30;

        node *current = params->SNAKE->head;
        while (current != NULL) {
            if (current->x == params->food.x && current->y == params->food.y) {
                clash = 1;
                break;
            }
            current = current->next;
        }
    } while (clash == 1);

    g_signal_connect(app, "activate", G_CALLBACK(activate), params);

    int status = g_application_run(G_APPLICATION(app), argc, argv);

    g_object_unref(app);
    return status;
}
