#ifndef B24EE1087_B24MT1045_B24MT1004_B24CI1031_SNAKE_H
#define B24EE1087_B24MT1045_B24MT1004_B24CI1031_SNAKE_H

#include <gdk/gdkkeysyms.h> // for GDK_KEY_*
#include <gtk/gtk.h>

#define WINDOW_SIZE 600

typedef enum {
    UP,
    LEFT,
    DOWN,
    RIGHT
} direction;

typedef struct{
    int x;
    int y;
}position;

typedef struct node {
    int x;
    int y;
    direction* dir;
    struct node* next;
} node;

typedef struct {
    node* head;
    node* tail;
    node* current;
} snake;

typedef struct{
    position food;
    snake* SNAKE;
}game_params;

//functions
void initialize_snake (snake* SNAKE);//done
void move_direction(node* NODE);
position update_position (position food, snake* SNAKE);//done
int check_collision(snake* SNAKE, int height, int width);//done
void add_head (snake* SNAKE);//done
void remove_tail(snake* SNAKE);
int eat_food (snake* SNAKE, position food);//done
int count_nodes(snake* SNAKE);//done
gboolean on_key_pressed(GtkEventControllerKey *controller, guint keyval, guint keycode, GdkModifierType state, gpointer user_data);

#endif // SNAKE_H

