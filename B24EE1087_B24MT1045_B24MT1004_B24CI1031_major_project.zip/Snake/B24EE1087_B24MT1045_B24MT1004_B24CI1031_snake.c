
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "B24EE1087_B24MT1045_B24MT1004_B24CI1031_snake.h"

void initialize_snake(snake* SNAKE) {
    node* new_node = (node*)malloc(sizeof(node));

    new_node->x = 20;
    new_node->y = 40;
    new_node->next = NULL;

    new_node->dir = (direction*)malloc(sizeof(direction));
    *(new_node->dir) = RIGHT;

    SNAKE->head = new_node;
    SNAKE->tail = new_node;
    SNAKE->current = new_node;
}

position update_position(position food, snake* SNAKE) {
    position newfood;

    if ((food.x == SNAKE->head->x) && (food.y == SNAKE->head->y)) {
        int clash;
        do {
            clash = 0;
            newfood.x = ((rand() % ((WINDOW_SIZE - 20) / 10)) * 10) + 10;
            newfood.y = ((rand() % ((WINDOW_SIZE - 40) / 10)) * 10) + 30;

            node* current = SNAKE->head;
            while (current != NULL) {
                if (current->x == newfood.x && current->y == newfood.y) {
                    clash = 1;
                    break;
                }
                current = current->next;
            }
        } while (clash == 1);

        return newfood;
    } else {
        return food;
    }
}

void move_direction(node* NODE) {
    if (NODE == NULL || NODE->dir == NULL) return;

    switch (*(NODE->dir)) {
        case UP:
            NODE->y -= 10;
            break;
        case DOWN:
            NODE->y += 10;
            break;
        case LEFT:
            NODE->x -= 10;
            break;
        case RIGHT:
            NODE->x += 10;
            break;
        default:
            break;
    }
}

int check_collision(snake* SNAKE, int height, int width) {
    if (!SNAKE || !SNAKE->head) return 0;

    node* current = SNAKE->head->next;

    while (current) {
        if ((SNAKE->head->x == current->x) && (SNAKE->head->y == current->y)) {
            return 1;
        }
        current = current->next;
    }

    if ((SNAKE->head->x <= 0) || (SNAKE->head->x >= width - 40) ||
        (SNAKE->head->y <= 20) || (SNAKE->head->y >= height - 80)) {
        return 1;
    }

    return 0;
}

void add_head(snake* SNAKE) {
    if (!SNAKE || !SNAKE->head || !SNAKE->head->dir) return;

    node* new_node = (node*)malloc(sizeof(node));
    new_node->dir = (direction*)malloc(sizeof(direction));
    *(new_node->dir) = *(SNAKE->head->dir);  // Copy direction from head

    new_node->x = SNAKE->head->x;
    new_node->y = SNAKE->head->y;

    move_direction(new_node);

    new_node->next = SNAKE->head;
    SNAKE->head = new_node;
}

void remove_tail(snake* SNAKE) {
    if (!SNAKE || !SNAKE->head || !SNAKE->head->next) return;

    node* temp = SNAKE->head;
    while (temp->next && temp->next->next) {
        temp = temp->next;
    }

    free(temp->next->dir);
    free(temp->next);
    temp->next = NULL;
    SNAKE->tail = temp;
}

int eat_food(snake* SNAKE, position food) {
    if (!SNAKE || !SNAKE->head) return 0;
    return (SNAKE->head->x == food.x && SNAKE->head->y == food.y);
}

int count_nodes(snake* SNAKE) {
    int count = 0;
    node* temp = SNAKE->head;

    while (temp) {
        count++;
        temp = temp->next;
    }

    return count;
}

gboolean on_key_pressed(GtkEventControllerKey *controller, guint keyval, guint keycode, GdkModifierType state, gpointer user_data) {
    game_params* params = (game_params*)user_data;
    if (!params || !params->SNAKE || !params->SNAKE->head || !params->SNAKE->head->dir) return FALSE;

    direction* current_dir = params->SNAKE->head->dir;

    switch (keyval) {
        case GDK_KEY_Up:
            if (abs(*current_dir - UP) != 2)
                *current_dir = UP;
            break;
        case GDK_KEY_Down:
            if (abs(*current_dir - DOWN) != 2)
                *current_dir = DOWN;
            break;
        case GDK_KEY_Left:
            if (abs(*current_dir - LEFT) != 2)
                *current_dir = LEFT;
            break;
        case GDK_KEY_Right:
            if (abs(*current_dir - RIGHT) != 2)
                *current_dir = RIGHT;
            break;
    }

    return TRUE;
}
